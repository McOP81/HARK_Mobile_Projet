package com.example.el_kadah_rachid_projet_vfinal.ui.home;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.el_kadah_rachid_projet_vfinal.R;
import com.example.el_kadah_rachid_projet_vfinal.DatabaseHelper;
import com.example.el_kadah_rachid_projet_vfinal.ui.home.HomeViewModel;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class HomeFragment extends Fragment implements SensorEventListener {

    private TextView chronometer;
    private TextView activityTextView;
    private Button startButton;
    private Button stopButton;
    private HomeViewModel homeViewModel;
    private Handler handler;
    private Runnable runnable;
    private long baseTime;

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private static final float THRESHOLD = 10f; // Seuil de détection
    private Map<Integer, String> activityMap;

    private static final String TAG = "HomeFragment";

    // Variables for location tracking
    private double latitudeStart, longitudeStart, altitudeStart;
    private double latitudeEnd, longitudeEnd, altitudeEnd;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        chronometer = root.findViewById(R.id.chronometer);
        activityTextView = root.findViewById(R.id.activity_text);
        startButton = root.findViewById(R.id.start_button);
        stopButton = root.findViewById(R.id.stop_button);

        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        handler = new Handler();

        activityMap = new HashMap<>();
        activityMap.put(1, "Walking");
        activityMap.put(2, "Jumping");
        activityMap.put(3, "Sitting");
        activityMap.put(4, "Standing");

        sensorManager = (SensorManager) requireActivity().getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (accelerometer != null) {
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            }
        }

        // Initialize LocationManager and LocationListener
        locationManager = (LocationManager) requireActivity().getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                // Retrieve current coordinates
                if (homeViewModel.isRunning().getValue() == null || !homeViewModel.isRunning().getValue()) {
                    latitudeStart = location.getLatitude();
                    longitudeStart = location.getLongitude();
                    altitudeStart = location.getAltitude();
                } else {
                    latitudeEnd = location.getLatitude();
                    longitudeEnd = location.getLongitude();
                    altitudeEnd = location.getAltitude();
                }
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}
            @Override
            public void onProviderEnabled(String provider) {}
            @Override
            public void onProviderDisabled(String provider) {}
        };

        // Request location permissions if necessary
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }

        homeViewModel.getChronometerBase().observe(getViewLifecycleOwner(), base -> {
            Log.d(TAG, "getChronometerBase observer called with base: " + base);
            if (base != null) {
                baseTime = base;
            }
        });

        homeViewModel.isRunning().observe(getViewLifecycleOwner(), running -> {
            Log.d(TAG, "isRunning observer called with running: " + running);
            if (running != null) {
                if (running) {
                    startChronometer();
                    updateButtonState(true);
                } else {
                    stopChronometer();
                    updateButtonState(false);
                }
            }
        });

        homeViewModel.getCurrentActivity().observe(getViewLifecycleOwner(), activity -> {
            if (activity != null) {
                activityTextView.setText("Activité actuel: " + activity);
            } else {
                activityTextView.setText("Activité actuelle : Inconnu");
            }
        });

        startButton.setOnClickListener(v -> {
            Log.d(TAG, "Bouton de démarrage cliqué");
            if (!homeViewModel.isRunning().getValue()) {
                baseTime = SystemClock.elapsedRealtime();
                homeViewModel.setChronometerBase(baseTime);
                homeViewModel.setRunning(true);

                // Retrieve the last known location for start coordinates
                Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (lastKnownLocation != null) {
                    latitudeStart = lastKnownLocation.getLatitude();
                    longitudeStart = lastKnownLocation.getLongitude();
                    altitudeStart = lastKnownLocation.getAltitude();
                }
            }
        });

        stopButton.setOnClickListener(v -> {
            Log.d(TAG, "Bouton d'arrêt cliqué");
            if (homeViewModel.isRunning().getValue()) {
                homeViewModel.setRunning(false);

                // Retrieve the last known location for end coordinates
                Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (lastKnownLocation != null) {
                    latitudeEnd = lastKnownLocation.getLatitude();
                    longitudeEnd = lastKnownLocation.getLongitude();
                    altitudeEnd = lastKnownLocation.getAltitude();
                }

                // Save the activity with date and time
                saveActivity();
            }
        });

        // Retrieve user ID from SharedPreferences and load user details
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);
        if (userId != -1) {
            loadUserDetails(userId);
        }

        return root;
    }

    private void startChronometer() {
        runnable = new Runnable() {
            @Override
            public void run() {
                long elapsedMillis = SystemClock.elapsedRealtime() - baseTime;
                int seconds = (int) (elapsedMillis / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;
                int milliseconds = (int) (elapsedMillis % 1000);
                String time = String.format("%02d:%02d:%03d", minutes, seconds, milliseconds);
                chronometer.setText(time);
                handler.postDelayed(this, 10);
            }
        };
        handler.post(runnable);
    }

    private void stopChronometer() {
        handler.removeCallbacks(runnable);
    }

    private void updateButtonState(boolean running) {
        startButton.setEnabled(!running);
        stopButton.setEnabled(running);

        if (running) {
            startButton.setBackgroundResource(R.drawable.button_start_disabled);
            stopButton.setBackgroundResource(R.drawable.button_stop_enabled);
        } else {
            startButton.setBackgroundResource(R.drawable.button_start_enabled);
            stopButton.setBackgroundResource(R.drawable.button_stop_disabled);
        }
    }

    private void loadUserDetails(int userId) {
        DatabaseHelper databaseHelper = new DatabaseHelper(requireContext());
        // Load user details from the database
    }

    private void saveActivity() {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId != -1) {
            String activityType = homeViewModel.getCurrentActivity().getValue();

            // Utiliser System.currentTimeMillis() pour obtenir la date actuelle en millisecondes depuis epoch
            long startTime = System.currentTimeMillis();
            long endTime = SystemClock.elapsedRealtime();
            long duration = endTime - baseTime;

            // Formater les dates de début et de fin au format "yyyy-MM-dd HH:mm:ss"
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String startTimeString = sdf.format(new Date(startTime));
            String endTimeString = sdf.format(new Date(startTime + duration)); // Calculer endTime à partir de startTime + duration

            DatabaseHelper databaseHelper = new DatabaseHelper(requireContext());
            boolean insertData = databaseHelper.addActivity(userId, activityType, startTimeString, endTimeString, duration, latitudeStart, longitudeStart, altitudeStart);

            if (insertData) {
                // Récupérer l'ID de l'activité ajoutée pour mettre à jour les coordonnées de fin
                Cursor cursor = databaseHelper.getAllActivities();
                if (cursor.moveToLast()) {
                    int activityId = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ACTIVITY_ID));
                    boolean updateData = databaseHelper.updateActivityEnd(activityId, latitudeEnd, longitudeEnd, altitudeEnd);
                    if (updateData) {
                        Log.d(TAG, "Coordonnées de fin de l'activité mises à jour avec succès");
                    } else {
                        Log.d(TAG, "Échec de la mise à jour des coordonnées de fin de l'activité");
                    }
                }
                cursor.close();
                Log.d(TAG, "Activité enregistrée avec succès");
            } else {
                Log.d(TAG, "Échec de l'enregistrement de l'activité");
            }
        } else {
            Log.e(TAG, "ID d'utilisateur non trouvé dans SharedPreferences");
        }
    }

    // Utility method to convert milliseconds to a readable time format
//    private String convertMillisToTimeString(long millis) {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
//        return sdf.format(new Date(millis));
//    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        double acceleration = Math.sqrt(x * x + y * y + z * z);

        double normX = (Math.abs(x) / SensorManager.GRAVITY_EARTH) * 100;
        double normY = (Math.abs(y) / SensorManager.GRAVITY_EARTH) * 100;
        double normZ = (Math.abs(z) / SensorManager.GRAVITY_EARTH) * 100;

        double walkingProbability = calculateProbability(normX, THRESHOLD, 0, 100);
        double jumpingProbability = calculateProbability(normZ, THRESHOLD, 100, 0);
        double sittingProbability = calculateProbability(acceleration, THRESHOLD, 100, 0);
        double standingProbability = calculateProbability(normY, THRESHOLD, 0, 100);

        displayConfidence((int) walkingProbability, (int) jumpingProbability, (int) sittingProbability, (int) standingProbability);
    }

    private double calculateProbability(double value, double threshold, double low, double high) {
        double probability;
        if (value < threshold) {
            probability = (value / threshold) * low;
        } else {
            probability = ((value - threshold) / (100 - threshold)) * high;
        }

        if (probability < 0) {
            probability = 0;
        } else if (probability > 100) {
            probability = 100;
        }

        return probability;
    }

    private void displayConfidence(int walking, int jumping, int sitting, int standing) {
        int highestProbability = Math.max(Math.max(walking, jumping), Math.max(sitting, standing));

        if (highestProbability == walking) {
            homeViewModel.setCurrentActivity(activityMap.get(1));
        } else if (highestProbability == jumping) {
            homeViewModel.setCurrentActivity(activityMap.get(2));
        } else if (highestProbability == sitting) {
            homeViewModel.setCurrentActivity(activityMap.get(3));
        } else if (highestProbability == standing) {
            homeViewModel.setCurrentActivity(activityMap.get(4));
        }
    }

//    private int getColorBasedOnProbability(int probability, int defaultColorId) {
//        if (probability >= 70) {
//            return getResources().getColor(defaultColorId);
//        } else if (probability >= 30) {
//            return adjustAlpha(getResources().getColor(defaultColorId), 0.5f);
//        } else {
//            return 0;
//        }
//    }

//    private int adjustAlpha(int color, float factor) {
//        int alpha = Math.round(android.graphics.Color.alpha(color) * factor);
//        int red = android.graphics.Color.red(color);
//        int green = android.graphics.Color.green(color);
//        int blue = android.graphics.Color.blue(color);
//        return android.graphics.Color.argb(alpha, red, green, blue);
//    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
        locationManager.removeUpdates(locationListener);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (sensorManager != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        sensorManager.unregisterListener(this);
        locationManager.removeUpdates(locationListener);
    }
}
