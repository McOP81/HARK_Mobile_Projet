package com.example.el_kadah_rachid_projet_vfinal.ui.profile;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.el_kadah_rachid_projet_vfinal.DatabaseHelper;
import com.example.el_kadah_rachid_projet_vfinal.R;
import com.example.el_kadah_rachid_projet_vfinal.databinding.FragmentProfileBinding;

import java.io.File;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding binding;
    private ProfileViewModel profileViewModel;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_profile, container, false);
        View root = binding.getRoot();

        // Initialize database helper
        databaseHelper = new DatabaseHelper(getContext());

        // Retrieve user ID from SharedPreferences
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId != -1) {
            loadUserDetails(userId);
        }

        // Observe ViewModel data and update views
        profileViewModel.getName().observe(getViewLifecycleOwner(), binding.titleName::setText);
        profileViewModel.getName().observe(getViewLifecycleOwner(), binding.profileName::setText);
        profileViewModel.getUsername().observe(getViewLifecycleOwner(), binding.titleUsername::setText);
        profileViewModel.getEmail().observe(getViewLifecycleOwner(), binding.profileEmail::setText);
        profileViewModel.getPassword().observe(getViewLifecycleOwner(), binding.profilePassword::setText);
        profileViewModel.getPhone().observe(getViewLifecycleOwner(), binding.profilePhone::setText);

        // Observe imagePath to update profileImg
        profileViewModel.getImagePath().observe(getViewLifecycleOwner(), imagePath -> {
            if (imagePath != null && !imagePath.isEmpty()) {
                // Load image from imagePath
                Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
                if (bitmap != null) {
                    binding.profileImg.setImageBitmap(bitmap);
                } else {
                    // Load default image if imagePath is not valid
                    binding.profileImg.setImageResource(R.drawable.logo);
                }
            } else {
                // No image path available, load default image
                binding.profileImg.setImageResource(R.drawable.logo);
            }
        });

        // Navigate to EditFragment when Edit Profile button is clicked
        Button editButton = binding.editButton;
        editButton.setOnClickListener(view -> {
            Navigation.findNavController(view).navigate(R.id.nav_edit);
        });

        return root;
    }

    private void loadUserDetails(int userId) {
        Cursor cursor = databaseHelper.getUserDetails(userId);
        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));
            String username = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EMAIL)); // Assuming username is stored in email for now
            String email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EMAIL));
            String password = "****";
            String phone = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PHONE));

            // Set user details to ViewModel
            profileViewModel.setUserDetails(name, username, email, password, phone);

            // Set imagePath to ViewModel (assuming imagePath is retrieved from cursor)
            String imagePath = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE_PATH));
            profileViewModel.setImagePath(imagePath);

            cursor.close();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
