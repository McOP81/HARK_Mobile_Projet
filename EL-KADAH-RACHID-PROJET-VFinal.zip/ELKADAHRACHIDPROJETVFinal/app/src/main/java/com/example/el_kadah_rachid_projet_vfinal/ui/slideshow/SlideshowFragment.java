package com.example.el_kadah_rachid_projet_vfinal.ui.slideshow;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.el_kadah_rachid_projet_vfinal.DatabaseHelper;
import com.example.el_kadah_rachid_projet_vfinal.R;

public class SlideshowFragment extends Fragment {

    private TableLayout tableLayout;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        tableLayout = root.findViewById(R.id.tableLayoutActivities);

        loadUserActivities();

        return root;
    }

    private void loadUserActivities() {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(getContext(), "ID de l'utilisateur non trouvé", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(getContext());
        Cursor cursor = dbHelper.getActivityCoordinatesByUserId(userId);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String activityType = cursor.getString(cursor.getColumnIndexOrThrow("activity_type"));
                String startTime = cursor.getString(cursor.getColumnIndexOrThrow("start_time"));
                String endTime = cursor.getString(cursor.getColumnIndexOrThrow("end_time"));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow("duration"));

                TableRow tableRow = new TableRow(getContext());
                tableRow.addView(createTextView(activityType));
                tableRow.addView(createTextView(startTime));
                tableRow.addView(createTextView(endTime));
                tableRow.addView(createTextView(duration));

                tableLayout.addView(tableRow);
            } while (cursor.moveToNext());

            cursor.close();
        }
    }

    private TextView createTextView(String text) {
        TextView textView = new TextView(getContext());
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        return textView;
    }
}
