package com.example.el_kadah_rachid_projet_vfinal.ui.gallery;

import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {
    // No additional implementation needed for this ViewModel as of now
}
