package com.example.el_kadah_rachid_projet_vfinal.ui.gallery;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.el_kadah_rachid_projet_vfinal.DatabaseHelper;
import com.example.el_kadah_rachid_projet_vfinal.GPSTracker;
import com.example.el_kadah_rachid_projet_vfinal.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class GalleryFragment extends Fragment implements OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    private GoogleMap gMap;
    private GalleryViewModel galleryViewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        galleryViewModel = new ViewModelProvider(this).get(GalleryViewModel.class);
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.mapView);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        return root;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        gMap = googleMap;
        if (isLocationEnabled()) {
            getLocation();
        } else {
            Toast.makeText(getContext(), "Veuillez activer les services de localisation", Toast.LENGTH_SHORT).show();
        }
        displaySavedCoordinates();
    }

    private void getLocation() {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            GPSTracker gpsTracker = new GPSTracker(getContext()) {
                @Override
                public void onLocationChanged(@NonNull Location location) {
                    updateLocationOnMap(location);
                }
            };

            Location location = gpsTracker.getLocation();

            if (location != null) {
                updateLocationOnMap(location);
            } else {
                Toast.makeText(getContext(), "Impossible d'obtenir l'emplacement", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateLocationOnMap(Location location) {
        if (location != null && gMap != null) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            LatLng locationLatLng = new LatLng(latitude, longitude);
//            gMap.clear();
//            gMap.addMarker(new MarkerOptions().position(locationLatLng).title("Current Location"));
//            gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(locationLatLng, 12));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (isLocationEnabled()) {
                    getLocation();
                } else {
                    Toast.makeText(getContext(), "Veuillez activer les services de localisation", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Autorisation de localisation refusée", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private void displaySavedCoordinates() {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(getContext(), "ID de l'utilisateur non trouvé", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(getContext());
        Cursor cursor = dbHelper.getActivityCoordinatesByUserIdEnd(userId);

        if (cursor != null && cursor.moveToFirst()) {
            double latitudeStart = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LATITUDE_START));
            double longitudeStart = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LONGITUDE_START));
            double latitudeEnd = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LATITUDE_END));
            double longitudeEnd = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LONGITUDE_END));

            LatLng startLatLng = new LatLng(latitudeStart, longitudeStart);
            LatLng endLatLng = new LatLng(latitudeEnd, longitudeEnd);
            BitmapDescriptor markerIcon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);

            gMap.addMarker(new MarkerOptions().position(startLatLng).title("Lieu de départ"));
            gMap.addMarker(new MarkerOptions().position(endLatLng).title("Lieu de fin").icon(markerIcon));

            // Tracer une ligne entre Start Location et End Location en rouge
            PolylineOptions polylineOptions = new PolylineOptions()
                    .add(startLatLng)
                    .add(endLatLng)
                    .color(ContextCompat.getColor(getContext(), R.color.red));  // Assurez-vous d'avoir défini la couleur rouge dans vos ressources

            gMap.addPolyline(polylineOptions);

            gMap.moveCamera(CameraUpdateFactory.newLatLngZoom(startLatLng, 14));

            cursor.close();
        }
    }
}
