package com.example.el_kadah_rachid_projet_vfinal.ui.profile;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ProfileViewModel extends ViewModel {
    private final MutableLiveData<String> name;
    private final MutableLiveData<String> username;
    private final MutableLiveData<String> email;
    private final MutableLiveData<String> password;
    private final MutableLiveData<String> phone;
    private final MutableLiveData<String> imagePath;

    public ProfileViewModel() {
        name = new MutableLiveData<>();
        username = new MutableLiveData<>();
        email = new MutableLiveData<>();
        password = new MutableLiveData<>();
        phone = new MutableLiveData<>();
        imagePath = new MutableLiveData<>();

        // Initialize with some default values
        name.setValue("John Doe");
        username.setValue("John");
        email.setValue("john.doe@example.com");
        password.setValue("****");
        phone.setValue("0777111106");
    }

    public LiveData<String> getName() {
        return name;
    }

    public LiveData<String> getUsername() {
        return username;
    }

    public LiveData<String> getEmail() {
        return email;
    }

    public LiveData<String> getPassword() {
        return password;
    }

    public LiveData<String> getPhone() {
        return phone;
    }

    public LiveData<String> getImagePath() {
        return imagePath;
    }

    public void setImagePath(String path) {
        imagePath.setValue(path);
    }

    public void setUserDetails(String name, String username, String email, String password, String phone) {
        this.name.setValue(name);
        this.username.setValue(username);
        this.email.setValue(email);
        this.password.setValue(password);
        this.phone.setValue(phone);
    }
}
