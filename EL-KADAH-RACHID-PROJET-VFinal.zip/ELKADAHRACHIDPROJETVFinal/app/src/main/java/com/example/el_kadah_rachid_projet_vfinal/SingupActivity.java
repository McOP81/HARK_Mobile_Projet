package com.example.el_kadah_rachid_projet_vfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SingupActivity extends AppCompatActivity {

    EditText nameEditText, emailEditText, phoneEditText, passwordEditText;
    CheckBox maleCheckBox, femaleCheckBox;
    Button signupButton;
    TextView loginRedirectText;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singup);

        // Initialize views
        nameEditText = findViewById(R.id.signup_name);
        emailEditText = findViewById(R.id.signup_email);
        phoneEditText = findViewById(R.id.signup_username); // This is actually for phone
        passwordEditText = findViewById(R.id.signup_password);
        maleCheckBox = findViewById(R.id.checkbox_male);
        femaleCheckBox = findViewById(R.id.checkbox_female);
        signupButton = findViewById(R.id.signup_button);
        loginRedirectText = findViewById(R.id.loginRedirectText);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set signup button click listener
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String phone = phoneEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                String gender = maleCheckBox.isChecked() ? "M" : femaleCheckBox.isChecked() ? "F" : "";

                if (validateInputs(name, email, phone, password, gender)) {
                    if (databaseHelper.emailExists(email)) {
                        emailEditText.setError("Cet e-mail est déjà utilisé. Veuillez en saisir un autre.");
                        emailEditText.requestFocus();
                    } else {
                        String hashedPassword = hashPassword(password);  // Hachage du mot de passe
                        boolean isInserted = databaseHelper.addUser(name, email, phone, hashedPassword, gender);
                        if (isInserted) {
                            Toast.makeText(SingupActivity.this, "Utilisateur enregistré avec succès", Toast.LENGTH_SHORT).show();
                            // Redirect to LoginActivity if registration is successful
                            Intent intent = new Intent(SingupActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(SingupActivity.this, "Échec de l'enregistrement", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });


        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SingupActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean validateInputs(String name, String email, String phone, String password, String gender) {
        if (name.isEmpty()) {
            nameEditText.setError("Le nom est obligatoire");
            nameEditText.requestFocus();
            return false;
        }
        if (email.isEmpty()) {
            emailEditText.setError("L'email est obligatoire");
            emailEditText.requestFocus();
            return false;
        }
        if (!isEmailValid(email)) {
            emailEditText.setError("L'email doit contenir '@' et se terminer par 'gmail.com'");
            emailEditText.requestFocus();
            return false;
        }
        if (phone.isEmpty()) {
            phoneEditText.setError("Le téléphone est obligatoire");
            phoneEditText.requestFocus();
            return false;
        }
        if (!isPhoneValid(phone)) {
            phoneEditText.setError("Le téléphone doit contenir uniquement des chiffres");
            phoneEditText.requestFocus();
            return false;
        }
        if (password.isEmpty()) {
            passwordEditText.setError("Mot de passe est obligatoire");
            passwordEditText.requestFocus();
            return false;
        }
        if (!isPasswordValid(password)) {
            passwordEditText.setError("Le mot de passe doit contenir au moins 8 caractères, dont une lettre majuscule, une lettre minuscule et un chiffre");
            passwordEditText.requestFocus();
            return false;
        }
        if (gender.isEmpty()) {
            Toast.makeText(this, "Veuillez sélectionner un sexe", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
    private boolean isEmailValid(String email) {
        return email.contains("@") && email.endsWith("gmail.com");
    }

    private boolean isPhoneValid(String phone) {
        return phone.matches("\\d+");
    }

    private boolean isPasswordValid(String password) {
        if (password.length() < 8) {
            return false;
        }
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasDigit = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(c)) {
                hasLowercase = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            }
        }
        return hasUppercase && hasLowercase && hasDigit;
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
