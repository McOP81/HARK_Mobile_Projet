package com.example.el_kadah_rachid_projet_vfinal.ui.edit;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.el_kadah_rachid_projet_vfinal.DatabaseHelper;

public class EditViewModel extends ViewModel {

    private DatabaseHelper databaseHelper;
    private MutableLiveData<String> name = new MutableLiveData<>();
    private MutableLiveData<String> email = new MutableLiveData<>();
    private MutableLiveData<String> phone = new MutableLiveData<>();
    private MutableLiveData<String> password = new MutableLiveData<>();
    private MutableLiveData<String> gender = new MutableLiveData<>();
    private MutableLiveData<Bitmap> profileImage = new MutableLiveData<>();

    public void init(DatabaseHelper dbHelper) {
        this.databaseHelper = dbHelper;
    }

    public LiveData<String> getName() {
        return name;
    }

    public LiveData<String> getEmail() {
        return email;
    }

    public LiveData<String> getPhone() {
        return phone;
    }

    public LiveData<String> getPassword() {
        return password;
    }

    public LiveData<String> getGender() {
        return gender;
    }

    public LiveData<Bitmap> getProfileImage() {
        return profileImage;
    }

    public void fetchUserData(int userId) {
        Cursor cursor = databaseHelper.getUserDetails(userId);
        if (cursor != null && cursor.moveToFirst()) {
            name.setValue(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME)));
            email.setValue(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EMAIL)));
            phone.setValue(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PHONE)));
            password.setValue(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PASSWORD)));
            gender.setValue(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_GENDER)));

            String imagePath = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_IMAGE_PATH));
            if (imagePath != null && !imagePath.isEmpty()) {
                Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
                profileImage.setValue(bitmap);
            }
            cursor.close();
        }
    }

    public boolean saveUserData(int userId, String name, String email, String phone, String password, String gender, String imagePath) {
        return databaseHelper.updateUser(userId, name, email, phone, password, gender, imagePath);
    }
}
