package com.example.el_kadah_rachid_projet_vfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user.db";
    private static final int DATABASE_VERSION = 1;

    // Table and columns
    public static final String TABLE_NAME = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_GENDER = "gender";
    public static final String COLUMN_IMAGE_PATH = "image_path"; // Add column for image path


    // Définition de la table pour les activités
    public static final String TABLE_ACTIVITIES = "activities";
    public static final String COLUMN_ACTIVITY_ID = "activity_id";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_ACTIVITY_TYPE = "activity_type";
    public static final String COLUMN_START_TIME = "start_time";
    public static final String COLUMN_END_TIME = "end_time";
    public static final String COLUMN_DURATION = "duration";
    public static final String COLUMN_LONGITUDE_START = "logitude_start";
    public static final String COLUMN_LATITUDE_START = "latitude_start";
    public static final String COLUMN_ALTITUDE_START = "altitude_start";
    public static final String COLUMN_LONGITUDE_END = "logitude_end";
    public static final String COLUMN_LATITUDE_END = "latitude_end";
    public static final String COLUMN_ALTITUDE_END = "altitude_end";

    // Create table SQL query
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_EMAIL + " TEXT UNIQUE, " +
                    COLUMN_PHONE + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT, " +
                    COLUMN_GENDER + " TEXT, " +
                    COLUMN_IMAGE_PATH + " TEXT);"; // Include column for image path

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public boolean addUser(String name, String email, String phone, String password, String gender) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PHONE, phone);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_GENDER, gender);
        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1; // returns true if insert is successful
    }


    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        return cursor;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COLUMN_ID };
        String selection = COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?";
        String[] selectionArgs = { email, password };
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;
    }
    public boolean emailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = { COLUMN_ID };
        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = { email };
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;
    }

    public int getUserId(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        int userId = -1; // Par défaut, ID invalide

        // Spécifiez la requête SQL pour récupérer l'ID de l'utilisateur en fonction de l'e-mail
        String selectQuery = "SELECT " + COLUMN_ID + " FROM " + TABLE_NAME + " WHERE " + COLUMN_EMAIL + " = ?";

        // Utilisez un objet Cursor pour exécuter la requête
        Cursor cursor = db.rawQuery(selectQuery, new String[]{email});

        // Vérifiez si le curseur contient des données
        if (cursor != null && cursor.moveToFirst()) {
            // Vérifiez si la colonne COLUMN_ID existe dans le curseur
            int columnIndex = cursor.getColumnIndex(COLUMN_ID);
            if (columnIndex != -1) {
                // L'e-mail correspondant a été trouvé, obtenez l'ID de l'utilisateur
                userId = cursor.getInt(columnIndex);
            }
        }

        // Fermez le curseur et la base de données
        if (cursor != null) {
            cursor.close();
        }
        db.close();

        return userId;
    }

    public Cursor getUserDetails(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
        return cursor;
    }

    public boolean updateUser(int id, String name, String email, String phone, String password, String gender, String imagePath) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PHONE, phone);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_GENDER, gender);
        values.put(COLUMN_IMAGE_PATH, imagePath); // Add image path

        int result = db.update(TABLE_NAME, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    // Création de la table pour les activités SQL query
    private static final String TABLE_ACTIVITIES_CREATE =
            "CREATE TABLE " + TABLE_ACTIVITIES + " (" +
                    COLUMN_ACTIVITY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER_ID + " INTEGER, " +
                    COLUMN_ACTIVITY_TYPE + " TEXT, " +
                    COLUMN_START_TIME + " INTEGER, " +
                    COLUMN_END_TIME + " INTEGER, " +
                    COLUMN_DURATION + " INTEGER, " +
                    COLUMN_LATITUDE_START + " DOUBLE, " +
                    COLUMN_LATITUDE_END + " DOUBLE, " +
                    COLUMN_LONGITUDE_START + " DOUBLE, " +
                    COLUMN_LONGITUDE_END + " DOUBLE, " +
                    COLUMN_ALTITUDE_START + " DOUBLE, " +
                    COLUMN_ALTITUDE_END + " DOUBLE);";

    // Ajoutez une méthode pour insérer une activité dans la base de données
    public boolean addActivity(int userId, String activityType, String startTime, String endTime, long duration, double latitudeStart, double longitudeStart, double altitudeStart) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USER_ID, userId);
        contentValues.put(COLUMN_ACTIVITY_TYPE, activityType);
        contentValues.put(COLUMN_START_TIME, startTime); // Utilisez startTime et endTime au format correct
        contentValues.put(COLUMN_END_TIME, endTime);
        contentValues.put(COLUMN_DURATION, duration);
        contentValues.put(COLUMN_LATITUDE_START, latitudeStart);
        contentValues.put(COLUMN_LONGITUDE_START, longitudeStart);
        contentValues.put(COLUMN_ALTITUDE_START, altitudeStart);

        long result = db.insert(TABLE_ACTIVITIES, null, contentValues);
        return result != -1;
    }


    public boolean updateActivityEnd(int activityId, double latitudeEnd, double longitudeEnd, double altitudeEnd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_LATITUDE_END, latitudeEnd);
        values.put(COLUMN_LONGITUDE_END, longitudeEnd);
        values.put(COLUMN_ALTITUDE_END, altitudeEnd);

        int result = db.update(TABLE_ACTIVITIES, values, COLUMN_ACTIVITY_ID + " = ?", new String[]{String.valueOf(activityId)});
        db.close();
        return result > 0;
    }

    public Cursor getActivityCoordinatesByUserIdEnd(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_LATITUDE_START + ", " + COLUMN_LONGITUDE_START + ", " + COLUMN_LATITUDE_END + ", " + COLUMN_LONGITUDE_END +
                " FROM " + TABLE_ACTIVITIES +
                " WHERE " + COLUMN_USER_ID + " = ?" +
                " ORDER BY " + COLUMN_ACTIVITY_ID + " DESC" +
                " LIMIT 1";
        return db.rawQuery(query, new String[]{String.valueOf(userId)});
    }


    public Cursor getActivityCoordinatesByUserId(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT activity_type, start_time, end_time, duration " +
                "FROM " + TABLE_ACTIVITIES +
                " WHERE " + COLUMN_USER_ID + " = ?";
        return db.rawQuery(query, new String[]{String.valueOf(userId)});
    }





    public Cursor getAllActivities() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_ACTIVITIES;
        return db.rawQuery(query, null);
    }

    // Mettez à jour onUpgrade() pour créer la table des activités si elle n'existe pas déjà
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        db.execSQL(TABLE_ACTIVITIES_CREATE); // Créez la table des activités lors de la création de la base de données
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACTIVITIES); // Supprimez la table des activités lors de la mise à jour
        onCreate(db);
    }
}
