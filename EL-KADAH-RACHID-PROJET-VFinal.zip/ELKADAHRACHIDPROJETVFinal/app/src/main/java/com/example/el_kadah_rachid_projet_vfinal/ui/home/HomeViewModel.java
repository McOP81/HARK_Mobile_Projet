package com.example.el_kadah_rachid_projet_vfinal.ui.home;


import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<Boolean> isRunning = new MutableLiveData<>(false);
    private final MutableLiveData<Long> chronometerBase = new MutableLiveData<>();
    private final MutableLiveData<String> currentActivity = new MutableLiveData<>();

    public LiveData<Boolean> isRunning() {
        return isRunning;
    }

    public void setRunning(boolean running) {
        isRunning.setValue(running);
    }

    public LiveData<Long> getChronometerBase() {
        return chronometerBase;
    }

    public void setChronometerBase(long base) {
        chronometerBase.setValue(base);
    }

    public LiveData<String> getCurrentActivity() {
        return currentActivity;
    }

    public void setCurrentActivity(String activity) {
        currentActivity.setValue(activity);
    }
}
