package com.example.el_kadah_rachid_projet_vfinal.ui.edit;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.el_kadah_rachid_projet_vfinal.DatabaseHelper;
import com.example.el_kadah_rachid_projet_vfinal.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static android.content.Context.MODE_PRIVATE;

public class EditFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditViewModel mViewModel;
    private EditText editName, editEmail, editPhone, editPassword;
    private CheckBox checkboxMale, checkboxFemale;
    private ImageView profileImage;
    private Button saveButton, chooseImageButton;
    private DatabaseHelper databaseHelper;
    private int userId;
    private String imagePath;

    public static EditFragment newInstance() {
        return new EditFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_edit, container, false);

        editName = view.findViewById(R.id.editName);
        editEmail = view.findViewById(R.id.editEmail);
        editPhone = view.findViewById(R.id.editPhone);
        editPassword = view.findViewById(R.id.editPassword);
        checkboxMale = view.findViewById(R.id.checkbox_male);
        checkboxFemale = view.findViewById(R.id.checkbox_female);
        profileImage = view.findViewById(R.id.profileImage);
        saveButton = view.findViewById(R.id.saveButton);
        chooseImageButton = view.findViewById(R.id.chooseImageButton);

        databaseHelper = new DatabaseHelper(getContext());

        // Retrieve user ID from SharedPreferences
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("user_session", MODE_PRIVATE);
        userId = sharedPreferences.getInt("user_id", -1);

        mViewModel = new ViewModelProvider(this).get(EditViewModel.class);
        mViewModel.init(databaseHelper);

        // Observe the LiveData from ViewModel
        mViewModel.getName().observe(getViewLifecycleOwner(), name -> editName.setText(name));
        mViewModel.getEmail().observe(getViewLifecycleOwner(), email -> editEmail.setText(email));
        mViewModel.getPhone().observe(getViewLifecycleOwner(), phone -> editPhone.setText(phone));
        mViewModel.getPassword().observe(getViewLifecycleOwner(), password -> editPassword.setText(password));
        mViewModel.getGender().observe(getViewLifecycleOwner(), gender -> {
            if ("M".equals(gender)) {
                checkboxMale.setChecked(true);
                checkboxFemale.setChecked(false);
            } else if ("F".equals(gender)) {
                checkboxFemale.setChecked(true);
                checkboxMale.setChecked(false);
            }
        });

        mViewModel.getProfileImage().observe(getViewLifecycleOwner(), bitmap -> {
            if (bitmap != null) {
                profileImage.setImageBitmap(bitmap);
            }
        });

        if (userId != -1) {
            mViewModel.fetchUserData(userId);
        }

        saveButton.setOnClickListener(v -> saveUserData());
        chooseImageButton.setOnClickListener(v -> openImageChooser());

        return view;
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                profileImage.setImageBitmap(bitmap);
                imagePath = saveImageToInternalStorage(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String saveImageToInternalStorage(Bitmap bitmap) {
        File filesDir = getContext().getFilesDir();
        File imageFile = new File(filesDir, "profile_image.png");

        try (OutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return imageFile.getAbsolutePath();
    }

    private void saveUserData() {
        String name = editName.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();
        String password = editPassword.getText().toString().trim();
        String gender = checkboxMale.isChecked() ? "M" : checkboxFemale.isChecked() ? "F" : "";
        String hashedPassword = hashPassword(password);

        boolean isUpdated = mViewModel.saveUserData(userId, name, email, phone, hashedPassword, gender, imagePath);
        if (isUpdated) {
            Toast.makeText(getContext(), "Les données utilisateur ont été enregistrées avec succès", Toast.LENGTH_SHORT).show();
            // Navigate back to the previous fragment
            NavController navController = Navigation.findNavController(getView());
            navController.popBackStack();
        } else {
            Toast.makeText(getContext(), "Impossible de sauvegarder les données utilisateur", Toast.LENGTH_SHORT).show();
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
